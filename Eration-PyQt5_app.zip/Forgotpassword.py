

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Forgot Password")
        Dialog.resize(396, 178)
        self.getpasswordbutton = QtWidgets.QPushButton(Dialog)
        self.getpasswordbutton.setGeometry(QtCore.QRect(200, 100, 151, 41))
        self.getpasswordbutton.setObjectName("getpasswordbutton")
        self.ration = QtWidgets.QLineEdit(Dialog)
        self.ration.setGeometry(QtCore.QRect(110, 30, 241, 51))
        self.ration.setObjectName("ration")
        self.cancelbutton = QtWidgets.QPushButton(Dialog)
        self.cancelbutton.setGeometry(QtCore.QRect(110, 100, 71, 41))
        self.cancelbutton.setObjectName("cancelbutton")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 30, 111, 51))
        self.label.setObjectName("label")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Forgot Password"))
        self.getpasswordbutton.setText(_translate("Dialog", "Get Password"))
        self.ration.setPlaceholderText(_translate("Dialog", "Enter Ration Card Number"))
        self.cancelbutton.setText(_translate("Dialog", "Cancel"))
        self.label.setText(_translate("Dialog", "<html><head/><body><p><span style=\" font-weight:600;\">User Id</span></p></body></html>"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
