from main import *
from Login import Ui_Dialog as Ui_Login
from signup import Ui_Dialog as Ui_Signup
from Myaccount import Ui_Dialog as Ui_Myaccount
from Forgotpassword import Ui_Dialog as Ui_Forgotpassword
from Changepassword import Ui_Change_Password
from Qrcode import Ui_Dialog as Ui_Qrcode
from register import *
from status import Ui_Dialog as Ui_status
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
from easygui import *
import math, random
import smtplib
import re
ordered_data=list()
pay_flag=list()
pay_flag.append(False)
paid_mon=list()

def send_ord_mail(sub,b0,b1,b2,b3,b4,b5,b7,b8,to):
    mail=smtplib.SMTP_SSL("smtp.gmail.com",465)
    mail.login('e.ration.services@gmail.com','Service@123')
    to=to+''
    msg= f'{sub}\n\n{b0}\n{b1}\n{b2}\n{b3}\n{b4}\n{b5}\n{b7}\n{b8}'
    mail.sendmail('e.ration.services@gmail.com',to,msg)
    mail.close()

#status class
class status(QDialog,Ui_status):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.submit.clicked.connect(self.sub)

    def sub(self):
        if(self.paid.isChecked()):
            Details=register_database.forgot_search(datau[0])
            lis=' ,'.join(ordered_data)
            sub='Your order is confirmed'
            b0='Hello '+Details[0][0]+'!'
            b1='We recevied your payment of '+str(paid_mon[0])+' Rs succesfully.'
            b2='Your ordered items are :'
            b3=lis+'.'
            b5='We will send you updates via to this mail once your order is prepared and ready to ship.'
            b4='Delivering at :'+Details[0][5]+'.'
            b7='Thank you,'
            b8='Team E-Ration Services.'
            to=Details[0][7]
            pay_flag.clear()
            pay_flag.append(True)
            fill_pop=QtWidgets.QMessageBox()
            fill_pop.setWindowTitle('Order Confirmed.')
            fill_pop.setText('Just Checking Few Things Enter ok to continue')
            fill_pop.setIcon(QtWidgets.QMessageBox.Information)
            fill_pop.exec_()
            send_ord_mail(sub,b0,b1,b2,b3,b4,b5,b7,b8,to)
            self.close()
        if(self.notpaid.isChecked()):
            print('Payment Failed\n\n')
            self.close()

#upi class
class showupi(QDialog,Ui_Qrcode):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.backbutton.clicked.connect(self.close)
        self.verifypayment.clicked.connect(self.check)

    def check(self):
        stobj=status()
        stobj.exec_()
        self.close()


#Register class object
register_database=Register("cred.db")
datau=list()
datap=list()
verify_email=list()
sub=' '
#otp genetator
def generateOTP(phno,n,sub) :
    digits = "0123456789"
    OTP = ""
    for i in range(6) :
        OTP += digits[math.floor(random.random() * 10)]
    b1='Dear '+n+','
    b2=OTP+' is your one time password(OTP).'
    b3='Please enter the OTP to proceed.'
    b4='Thank you,'
    b5='Team E-Ration Services'
    #to get email from database
    det=register_database.forgot_search(datau[0])
    if(det==False):
        to=verify_email[0]
    else:
        to=det[0][7]

    pop=QtWidgets.QMessageBox()
    pop.setWindowTitle('OTP Generating')
    pop.setText('Press ok to get OTP\nWe are trying to send the OTP\nThis might take upto 1 minute depending on Network connectivity')
    pop.setIcon(QtWidgets.QMessageBox.Information)
    pop.exec_()
    sendemail(sub,b1,b2,b3,b4,b5,to)
    text = "Enter the OTP Sent To The Register Gmail :"+to
    title = "OTP Portal"
    default_password = ""
    output = passwordbox(text, title, default_password)
    user_otp =str(output)
    return [OTP,user_otp]

def sendemail(sub,b1,b2,b3,b4,b5,to):
    mail=smtplib.SMTP_SSL("smtp.gmail.com",465)
    mail.login('e.ration.services@gmail.com','Service@123')
    to=to+''
    s='OTP For E-Ration Services'
    msg= f'{sub}\n\n{s}\n\n{b1}\n{b2}\n{b3}\n{b4}\n{b5}'
    mail.sendmail('e.ration.services@gmail.com',to,msg)
    mail.close()

#change password call
class Changepassword(QDialog,Ui_Change_Password):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.cancelbutton.clicked.connect(self.close)
        self.forgotbutton.clicked.connect(self.generateforgotpassword)
        self.okbutton.clicked.connect(self.cp)

    def cp(self):
        op=self.oldpass.text()
        np=self.newpass.text()
        cp=self.conpass.text()
        if(len(op)==0 or len(np)==0 or len(cp)==0):
            self.fill_pop=QtWidgets.QMessageBox()
            self.fill_pop.setWindowTitle('Change Password')
            self.fill_pop.setText('Please Fill All The Fields')
            self.fill_pop.setIcon(QtWidgets.QMessageBox.Information)
            self.fill_pop.exec_()
        elif(op!=datap[0]):
            self.fill_pop=QtWidgets.QMessageBox()
            self.fill_pop.setWindowTitle('Change Password')
            self.fill_pop.setText('You Entered Incorrect Old Passsword')
            self.fill_pop.setIcon(QtWidgets.QMessageBox.Warning)
            self.fill_pop.exec_()
        elif((len(np)>=6 and bool(re.match(r'\w*[A-Z]\w*',np)) and  bool(re.match(r'\w*[@_!#$%^&*()<>?/\|}{~:]\w*',np)))==False):
            self.Mpass_pop=QtWidgets.QMessageBox()
            self.Mpass_pop.setWindowTitle('change password')
            self.Mpass_pop.setText('Requirements: 1 Upper Case letter , 1 special symbol and Minimum length of password is 6.')
            self.Mpass_pop.setIcon(QtWidgets.QMessageBox.Critical)
            self.Mpass_pop.exec_()
        elif(np!=cp):
            self.Mpass_pop=QtWidgets.QMessageBox()
            self.Mpass_pop.setWindowTitle('Change Password')
            self.Mpass_pop.setText('New and Conform passwords did\'nt matched')
            self.Mpass_pop.setIcon(QtWidgets.QMessageBox.Critical)
            self.Mpass_pop.exec_()
        else:
            det=register_database.forgot_search(datau[0])
            otp=generateOTP(det[0][3],det[0][0],'Chage Password Verification')
            if(otp[0]==otp[1]):
                register_database.update_pass(datau[0],np)
                datap.clear()
                datap.append(np)
                self.acc_cre=QtWidgets.QMessageBox()
                self.acc_cre.setWindowTitle('Change Password')
                self.acc_cre.setText('Succesfully Changed Password ')
                self.acc_cre.setIcon(QtWidgets.QMessageBox.Information)
                self.acc_cre.exec_()
                self.close()
            else:
                self.acc_cre=QtWidgets.QMessageBox()
                self.acc_cre.setWindowTitle('Change Password')
                self.acc_cre.setText('Wrong OTP entered please try again.')
                self.acc_cre.setIcon(QtWidgets.QMessageBox.Critical)
                self.acc_cre.exec_()




    def generateforgotpassword(self):
        forgotpassobj=Forgortpassword()
        forgotpassobj.exec_()

#Forgot Password call
class Forgortpassword(QDialog,Ui_Forgotpassword):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.cancelbutton.clicked.connect(self.close_Forgotpassword)
        self.getpasswordbutton.clicked.connect(self.getpass)



    def getpass(self):
        if(len(self.ration.text())==0):
            self.for_pop=QtWidgets.QMessageBox()
            self.for_pop.setWindowTitle('Forgot Password')
            self.for_pop.setText('Please Enter User Id')
            self.for_pop.setIcon(QtWidgets.QMessageBox.Information)
            self.for_pop.exec_()
        else:
            u=self.ration.text()
            det=register_database.forgot_search(u)
            if(det==False):
                self.for_pop=QtWidgets.QMessageBox()
                self.for_pop.setWindowTitle('Forgot Password')
                self.for_pop.setText('Please Enter A Valid User Id')
                self.for_pop.setIcon(QtWidgets.QMessageBox.Warning )
                self.for_pop.exec_()
            else:
                pas=det[0][2]
                phno=det[0][3]
                n=det[0][0]
                datau.clear()
                datau.clear()
                datau.append(det[0][1])
                datap.append(det[0][2])
                otp=generateOTP(phno,n,'Forgot Password Verification')
                if(otp[0]==otp[1]):
                    self.showpass_pop=QtWidgets.QMessageBox()
                    self.showpass_pop.setWindowTitle('Password')
                    pas='Your Password :'+pas
                    self.showpass_pop.setText(pas)
                    self.showpass_pop.setIcon(QtWidgets.QMessageBox.Information)
                    self.showpass_pop.show()
                    self.showpass_pop.exec_()
                    self.close()
                else:
                    self.errpass_pop=QtWidgets.QMessageBox()
                    self.errpass_pop.setWindowTitle('OTP')
                    self.errpass_pop.setText('Wrong OTP Entered')
                    self.errpass_pop.setIcon(QtWidgets.QMessageBox.Warning)
                    self.errpass_pop.show()
                    self.errpass_pop.exec_()
                    self.close()



    def close_Forgotpassword(self):
        self.close()


#Myaccount class call
class Myaccount(QDialog,Ui_Myaccount):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.backbutton.clicked.connect(self.close_myaccount)




    def close_myaccount(self):
        self.close()


#signup class call
class Signup(QDialog,Ui_Signup):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.signupButton.clicked.connect(self.adduser)
        self.cancelbutton.clicked.connect(self.close_signup)

    def close_signup(self):
        self.close()

    def adduser(self):
        n=self.name.text()
        userid=self.ration.text()
        v_uid=re.findall('[0-9]+', userid)
        datau.clear()
        datau.append(userid)
        password=self.password.text()
        phno=self.phoneno.text()
        lstph = re.findall('[0-9]+', phno)
        sal=self.income.text()
        dob=self.date.text()#
        address=self.address.text()
        emailid=self.email.text()
        verify_email.clear()
        verify_email.append(emailid)
        lst=re.findall('\S+@gmail.com',emailid)
        self.flag=register_database.forgot_search(userid)
        if(len(self.name.text())==0 or len(self.ration.text())==0 or len(self.password.text())==0 or len(self.conformpass.text())==0 or len(self.phoneno.text())==0 or len(self.income.text())==0 or len(self.date.text())==0 or len(self.address.text())==0 or len(emailid)==0):
            self.fill_pop=QtWidgets.QMessageBox()
            self.fill_pop.setWindowTitle('Signup')
            self.fill_pop.setText('Fill All The Fields')
            self.fill_pop.setIcon(QtWidgets.QMessageBox.Information)
            self.fill_pop.exec_()

        elif(len(v_uid[0])!=10):
            self.Mpass_pop=QtWidgets.QMessageBox()
            self.Mpass_pop.setWindowTitle('Acoount creation')
            self.Mpass_pop.setText('Ration Card Number Must be 10 digits')
            self.Mpass_pop.setIcon(QtWidgets.QMessageBox.Information)
            self.Mpass_pop.exec_()

        elif(self.password.text()!=self.conformpass.text()):
            self.Mpass_pop=QtWidgets.QMessageBox()
            self.Mpass_pop.setWindowTitle('Acoount creation')
            self.Mpass_pop.setText('passwords did\'nt matched')
            self.Mpass_pop.setIcon(QtWidgets.QMessageBox.Critical)
            self.Mpass_pop.exec_()

        elif((len(self.password.text())>=6 and bool(re.match(r'\w*[A-Z]\w*',self.password.text())) and  bool(re.match(r'\w*[@_!#$%^&*()<>?/\|}{~:]\w*',self.password.text())))==False):
            self.Mpass_pop=QtWidgets.QMessageBox()
            self.Mpass_pop.setWindowTitle('Acoount creation')
            self.Mpass_pop.setText('Requirements: 1 Upper Case letter , 1 special symbol and Minimum length of password is 6.')
            self.Mpass_pop.setIcon(QtWidgets.QMessageBox.Critical)
            self.Mpass_pop.exec_()

        elif(len(lstph[0])!=10):
            self.f_pop=QtWidgets.QMessageBox()
            self.f_pop.setWindowTitle('Phone Number')
            self.f_pop.setText('Phone Number Must Be 10 Digits')
            self.f_pop.setIcon(QtWidgets.QMessageBox.Information)
            self.f_pop.exec_()
        elif(len(lst)==0):
            self.f_pop=QtWidgets.QMessageBox()
            self.f_pop.setWindowTitle('Invalid Gmail')
            self.f_pop.setText('Please Enter Valid Gmail Id')
            self.f_pop.setIcon(QtWidgets.QMessageBox.Information)
            self.f_pop.exec_()
        else:
            if(self.flag==False):
                otp=generateOTP(phno,n,'Sign Up Verification')
                if(otp[0]==otp[1]):
                    self.acc_cre=QtWidgets.QMessageBox()
                    self.acc_cre.setWindowTitle('Acoount creation')
                    self.acc_cre.setText('Succesfully created account')
                    self.acc_cre.setIcon(QtWidgets.QMessageBox.Information)
                    self.acc_cre.exec_()
                    register_database.add(n,userid,password,phno,sal,address,dob,emailid)
                    self.close()
                else:
                    self.errpass_pop=QtWidgets.QMessageBox()
                    self.errpass_pop.setWindowTitle('Acoount creation')
                    self.errpass_pop.setText('Wrong OTP entered failed to create new account')
                    self.errpass_pop.setIcon(QtWidgets.QMessageBox.Warning)
                    self.errpass_pop.show()
                    self.errpass_pop.exec_()

            else:
                self.u_cre=QtWidgets.QMessageBox()
                self.u_cre.setWindowTitle('Acoount creation')
                self.u_cre.setText('Account Already exists')
                self.u_cre.setIcon(QtWidgets.QMessageBox.Warning)
                self.u_cre.exec_()




#login class call
class Login(QDialog,Ui_Login):
    def __init__(self,parent=None):
        QDialog.__init__(self,parent)
        self.setupUi(self)
        self.loginbutton.clicked.connect(self.checkval)
        self.signupbutton.clicked.connect(self.generatesignup)
        self.forgotpasswordbutton.clicked.connect(self.generateforgotpassword)

    def generateforgotpassword(self):
        forgotpassobj=Forgortpassword()
        forgotpassobj.exec_()


    def checkval(self):
        self.u=self.user.text()
        rationno=self.user.text()
        p=self.password.text()
        self.flag=register_database.search(self.u,p)
        if(len(self.user.text())==0 or len(self.password.text())==0):
            self.fill_pop=QtWidgets.QMessageBox()
            self.fill_pop.setWindowTitle('Login')
            self.fill_pop.setText('Fill All The Fields')
            self.fill_pop.setIcon(QtWidgets.QMessageBox.Information)
            self.fill_pop.exec_()

        elif(self.flag==False):
            self.p_pop=QtWidgets.QMessageBox()
            self.p_pop.setWindowTitle('Login')
            self.p_pop.setText('Invalid Login Details')
            self.p_pop.setIcon(QtWidgets.QMessageBox.Warning)
            self.p_pop.exec_()

        elif(self.flag==True):
            datau.clear()
            datap.clear()
            datau.append(self.u)
            datap.append(p)
            self.s_pop=QtWidgets.QMessageBox()
            self.s_pop.setWindowTitle('Congrats')
            self.s_pop.setText('Succesfully logged in')
            self.s_pop.setIcon(QtWidgets.QMessageBox.Information)
            self.s_pop.exec_()
            self.close()


    def generatesignup(self):
        signobj=Signup()
        signobj.exec_()



#serivces/main window class call
class MainWindow(QMainWindow,Ui_MainWindow):
    def __init__(self,parent=None):
        QMainWindow.__init__(self,parent)
        self.setupUi(self)
        self.checklogin()
        self.logoutbutton.clicked.connect(self.close_win)
        self.purchasebutton.clicked.connect(self.calc)
        self.userinfo.clicked.connect(self.getdetail)
        self.clearbutton.clicked.connect(self.clear)
        self.changepasswordbutton.clicked.connect(self.open_cp)

    def open_cp(self):
        self.chapassobj=Changepassword()
        self.chapassobj.exec_()


    def close_win(self):
        self.poplog_out=QtWidgets.QMessageBox()
        self.poplog_out.setWindowTitle('Log out')
        self.poplog_out.setText('Succesfully Logged Out')
        self.poplog_out.setIcon(QtWidgets.QMessageBox.Information)
        self.close()
        self.poplog_out.exec_()



    def checklogin(self):
        self.loginobj=Login()
        self.loginobj.exec_()
        if self.loginobj.flag is True:
            self.data=register_database.getbyuser(self.loginobj.u)


    def getdetail(self):
        userobj=Myaccount()
        userobj.name.setText(self.data[0][0])
        userobj.ration.setText(self.data[0][1])
        userobj.phoneno.setText(self.data[0][3])
        userobj.income.setText(self.data[0][4])
        userobj.address.setText(self.data[0][5])
        userobj.dob.setText(self.data[0][6])
        userobj.email.setText(self.data[0][7])
        userobj.exec_()


    def calc(self):
        sum=0
        ordered_data.clear()
        if(self.ricebox.isChecked()):
            sum=sum+self.qrice.value()*7
            print('Rice Quantity :',self.qrice.value(),'        Cost :',self.qrice.value()*7)
            ordered_data.append('Rice '+str(self.qrice.value())+' Kg')
        if(self.sugarbox.isChecked()):
            sum=sum+self.qsugar.value()*13
            print('Sugar Quantity :',self.qsugar.value(),'       Cost :',self.qsugar.value()*13)
            ordered_data.append('Sugar '+str(self.qsugar.value())+' Kg')
        if(self.kerosenebox.isChecked()):
            sum=sum+self.qkerosene.value()*22
            print('Kerosene Quantity :',self.qkerosene.value(),'    Cost :',self.qkerosene.value()*22)
            ordered_data.append('Kerosene '+str(self.qkerosene.value())+' L')
        if(self.oilbox.isChecked()):
            sum=sum+self.qoil.value()*30
            print('Oil Quantity :',self.qoil.value(),'         Cost :',self.qoil.value()*30)
            ordered_data.append('Oil '+str(self.qoil.value())+' L')
        if(self.fertilizersbox.isChecked()):
            sum=sum+self.qfertilizers.value()*37
            print('Fertilizers Quantity :',self.qfertilizers.value(),' Cost :',self.qfertilizers.value()*37)
            ordered_data.append('Fertilizers '+str(self.qfertilizers.value())+' Bag')
        if(self.wheatbox.isChecked()):
            sum=sum+self.qwheat.value()*26
            print('Atta Quantity :',self.qwheat.value(),'        Cost :',self.qwheat.value()*26)
            ordered_data.append('Atta '+str(self.qwheat.value())+' Kg')
        if(self.saltbox.isChecked()):
            sum=sum+self.qsalt.value()*9
            print('Salt Quantity :',self.qsalt.value(),'        Cost :',self.qsalt.value()*9)
            ordered_data.append('Salt '+str(self.qsalt.value())+' Kg')
        self.popbill=QtWidgets.QMessageBox()
        self.popbill.setWindowTitle('Scan QR Code')
        print('Total Bill : ',sum)
        print()
        paid_mon.clear()
        paid_mon.append(sum)
        if(sum!=0):
            self.popbill.setText('Use Google pay / Paytm / phonePe / Any BHMI upi app to scan the QR code.')
            self.popbill.setIcon(QtWidgets.QMessageBox.Information)
            self.popbill.show()
            self.popbill.exec_()
            obj=showupi()
            obj.exec_()
            if(pay_flag[0]):
                print('Payment Successfull.')
                print('Check Your Mail For Further Details.\n\n')
                pay_flag.clear()
                pay_flag.append(False)
                self.clear()

    def clear(self):
        self.ricebox.setChecked(False)
        self.sugarbox.setChecked(False)
        self.kerosenebox.setChecked(False)
        self.oilbox.setChecked(False)
        self.wheatbox.setChecked(False)
        self.fertilizersbox.setChecked(False)
        self.saltbox.setChecked(False)
        self.qrice.setValue(0)
        self.qsugar.setValue(0)
        self.qkerosene.setValue(0)
        self.qoil.setValue(0)
        self.qwheat.setValue(0)
        self.qfertilizers.setValue(0)
        self.qsalt.setValue(0)


if __name__=="__main__":
    #to create application
    app=QApplication(sys.argv)
    #main window object
    w=MainWindow()
    w.show()
    sys.exit(app.exec_())
