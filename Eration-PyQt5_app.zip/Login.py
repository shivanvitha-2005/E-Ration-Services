# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Login.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(532, 458)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(90, 10, 441, 81))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(60, 130, 111, 51))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(60, 180, 111, 71))
        self.label_3.setObjectName("label_3")
        self.signupbutton = QtWidgets.QPushButton(Dialog)
        self.signupbutton.setGeometry(QtCore.QRect(330, 390, 121, 41))
        self.signupbutton.setObjectName("signupbutton")
        self.loginbutton = QtWidgets.QPushButton(Dialog)
        self.loginbutton.setGeometry(QtCore.QRect(190, 280, 101, 41))
        self.loginbutton.setObjectName("loginbutton")
        self.user = QtWidgets.QLineEdit(Dialog)
        self.user.setGeometry(QtCore.QRect(190, 120, 251, 51))
        self.user.setCursorMoveStyle(QtCore.Qt.LogicalMoveStyle)
        self.user.setObjectName("user")
        self.password = QtWidgets.QLineEdit(Dialog)
        self.password.setGeometry(QtCore.QRect(190, 200, 251, 51))
        self.password.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password.setObjectName("password")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(70, 360, 261, 91))
        self.label_4.setObjectName("label_4")
        self.forgotpasswordbutton = QtWidgets.QPushButton(Dialog)
        self.forgotpasswordbutton.setGeometry(QtCore.QRect(300, 280, 151, 41))
        self.forgotpasswordbutton.setObjectName("forgotpasswordbutton")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Login"))
        self.label.setText(_translate("Dialog", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">E-RATION CARD SERVICES</span></p></body></html>"))
        self.label_2.setText(_translate("Dialog", "<html><head/><body><p><span style=\" font-size:10pt;\">UserId</span></p></body></html>"))
        self.label_3.setText(_translate("Dialog", "<html><head/><body><p><span style=\" font-size:10pt;\">Password</span></p></body></html>"))
        self.signupbutton.setText(_translate("Dialog", "Sign up"))
        self.loginbutton.setText(_translate("Dialog", "Log in"))
        self.user.setPlaceholderText(_translate("Dialog", "Enter  Ration Card Number"))
        self.password.setPlaceholderText(_translate("Dialog", "Enter Your Password"))
        self.label_4.setText(_translate("Dialog", "<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">Don\'t Have An Account?</span></p></body></html>"))
        self.forgotpasswordbutton.setText(_translate("Dialog", "Forgot Password"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
