import sqlite3

class Register:
    def __init__(self,db):
        self.conn=sqlite3.connect(db)
        self.cur=self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS LOGIN(name Text,user TEXT,password TEXT,phoneno TEXT,income TEXT,address TEXT,dob TEXT,emailid TEXT)")
        self.conn.commit()

    def add(self,name,user,password,phoneno,sal,address,dob,emailid):
        self.cur.execute("INSERT INTO LOGIN VALUES (?,?,?,?,?,?,?,?)",(name,user,password,phoneno,sal,address,dob,emailid,))
        self.conn.commit()


    def search(self,u,p):
        row=self.cur.execute("SELECT * FROM LOGIN WHERE user=? and password=?",(u,p)).fetchall()
        if not row:
            return False
        else:
            return True

    def forgot_search(self,u):
        row=self.cur.execute("SELECT * FROM LOGIN WHERE user=?",(u,)).fetchall()
        if not row:
            return False
        else:
            return row

    def update_pass(self,u,np):
        self.cur.execute("UPDATE LOGIN SET password=? WHERE user=?",(np,u))
        self.conn.commit()


    def getbyuser(self,user):
        row=self.cur.execute("SELECT * FROM LOGIN WHERE user=?",(user,)).fetchall()
        return row
